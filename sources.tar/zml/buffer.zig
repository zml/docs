const std = @import("std");

const pjrt = @import("pjrt");
const stdx = @import("stdx");

const constants = @import("constants.zig");
const DataType = @import("dtype.zig").DataType;
const Memory = @import("platform.zig").Memory;
const pjrtx = @import("pjrtx.zig");
const Platform = @import("platform.zig").Platform;
const Shape = @import("shape.zig").Shape;
const sharding_ = @import("sharding.zig");
const Sharding = sharding_.Sharding;
const Placement = sharding_.Placement;
const Slice = @import("slice.zig").Slice;
const Target = @import("platform.zig").Target;
const testing = @import("testing.zig");

const log = std.log.scoped(.zml);

/// Buffer is a multi-dimension array, whose memory is allocated on an accelerator.
///
/// * contains a handle that the ZML runtime can use to convert into a physical address, but there is no guarantee this address is visible from the CPU.
/// * loading weights from disk directly to the `device zml.aio.loadBuffers`
/// * can be created by calling `HostBuffer.toDevice(platform)`.
pub const Buffer = struct {
    _platform: *const Platform,
    _shape: Shape,
    _sharding: Sharding,
    _shards: Shards,

    pub const MAX_NUM_SHARDS: u16 = Platform.MAX_NUM_DEVICES;
    pub const Shards = stdx.BoundedArray(*pjrt.Buffer, MAX_NUM_SHARDS);

    pub const Shard = struct {
        _platform: *const Platform,
        _pjrt_buffer: *pjrt.Buffer,

        pub fn devicePtr(self: *const Shard) *anyopaque {
            return self._pjrt_buffer.opaqueDeviceMemoryDataPointer(self._platform.pjrt_api) catch unreachable;
        }
    };

    pub const ShardIterator = struct {
        _platform: *const Platform,
        _shards: []const *pjrt.Buffer,
        _index: usize = 0,

        pub fn remaining(self: *ShardIterator) usize {
            return self._shards.len -| self._index;
        }

        pub fn next(self: *ShardIterator) ?Shard {
            defer self._index += 1;
            if (self._index >= self._shards.len) return null;

            return .{
                ._pjrt_buffer = self._shards[self._index],
                ._platform = self._platform,
            };
        }
    };

    pub const FromOptions = struct { wait: bool = true, memory: Memory.Kind = .default };

    /// Frees the accelerator memory.
    /// Depending on the platform, the memory is typically not released to the OS
    /// but just marked as available in the memory pool.
    pub fn deinit(self: *Buffer) void {
        for (self._shards.constSlice()) |buffer| {
            buffer.deinit(self._platform.pjrt_api);
        }
    }

    /// This Buffer shape.
    pub fn shape(self: Buffer) Shape {
        return self._shape;
    }

    pub fn shards(self: *const Buffer) ShardIterator {
        return .{
            ._platform = self._platform,
            ._shards = self._shards.constSlice(),
        };
    }

    pub fn format(self: Buffer, writer: *std.Io.Writer) !void {
        try writer.print("{f}", .{self.placement()});
    }

    /// Copies the content of the given buffer from host memory to the accelerator memory.
    pub fn from(
        io: std.Io,
        platform: *const Platform,
        sh: Shape,
        sharding: Sharding,
        data_: []const u8,
        opts: FromOptions,
    ) !Buffer {
        var res: Buffer = .{
            ._platform = platform,
            ._shape = sh,
            ._sharding = sharding,
            ._shards = .{},
        };

        const buffer_type = pjrtx.bufferTypeFromDtype(sh.dtype());
        const slice = Slice.init(sh, data_);

        for (res.placement().shards.constSlice()) |shard| {
            const sub_slice = shard.shardSlice(slice);
            var default_layout: ?pjrt.DefaultMemoryLayout = null;
            const layout: pjrt.MemoryLayout = switch (platform.target) {
                .tpu => blk: {
                    default_layout = try platform.pjrt_client.defaultMemoryLayout(
                        platform.pjrt_api,
                        pjrtx.bufferTypeFromDtype(shard.shape.dtype()),
                        shard.shape.dims(),
                    );
                    break :blk default_layout.?.toMemoryLayout();
                },
                else => .{
                    .tiled = .{
                        .minor_to_major = constants.minorToMajor(shard.shape.rank()),
                        .tile_dims = &.{},
                        .tile_dims_sizes = &.{},
                    },
                },
            };
            const args: pjrt.Client.BufferFromHostBufferArgs = .{
                .data = sub_slice.constData().ptr,
                .buffer_type = buffer_type,
                .dims = shard.shape.dims(),
                .byte_strides = sub_slice.byte_strides.constSlice(),
                .layout = layout,
                .host_buffer_semantics = .ImmutableUntilTransferCompletes,
                .dst = .{ .memory = shard.memory(platform, opts.memory).pjrt_memory },
            };

            const pjrt_buffer, const event = try platform.pjrt_client.bufferFromHostBuffer(platform.pjrt_api, args);
            if (event) |ev| ev.deinit(platform.pjrt_api);

            res._shards.appendAssumeCapacity(pjrt_buffer);
        }

        if (opts.wait) {
            try res.await(io);
        }

        return res;
    }

    /// Copies the given Zig bytes to the accelerator memory and
    /// return a Buffer with the given dimensions.
    pub fn fromBytes(io: std.Io, platform: *const Platform, sh: Shape, sharding: Sharding, data: []const u8) !Buffer {
        return from(io, platform, sh, sharding, data, .{});
    }

    /// Copies the given zml.Slice to the accelerator memory and
    /// return a Buffer.
    pub fn fromSlice(io: std.Io, platform: *const Platform, slice: Slice, sharding: Sharding) !Buffer {
        return fromSliceOpts(io, platform, slice, sharding, .{});
    }

    pub fn fromSliceOpts(io: std.Io, platform: *const Platform, slice: Slice, sharding: Sharding, opts: FromOptions) !Buffer {
        return from(io, platform, slice.shape, sharding, std.mem.sliceAsBytes(slice.constData()), opts);
    }

    /// Creates a Buffer with a single element.
    pub fn scalar(io: std.Io, platform: *const Platform, val: anytype, dtype_: DataType, sharding: Sharding) !Buffer {
        const x = dtype_.constant(val);
        return fromBytes(io, platform, Shape.init(.{}, dtype_), sharding, x.asBytes());
    }

    pub fn await(self: Buffer, io: std.Io) !void {
        for (self._shards.constSlice()) |buffer| {
            const ev = buffer.readyEvent(self._platform.pjrt_api);
            defer ev.deinit(self._platform.pjrt_api);
            try ev.await(self._platform.pjrt_api, io);
        }
    }

    pub const UnitializedOptions = struct { memory: Memory.Kind = .default };

    pub fn uninitialized(
        _: std.Io,
        platform: *const Platform,
        sh: Shape,
        sharding: Sharding,
        opts: UnitializedOptions,
    ) !Buffer {
        var res: Buffer = .{
            ._platform = platform,
            ._shape = sh,
            ._sharding = sharding,
            ._shards = .{},
        };
        errdefer for (res._shards.slice()) |shard| {
            shard.deinit(platform.pjrt_api);
        };

        for (res.placement().shards.constSlice()) |shard| {
            var default_layout: ?pjrt.DefaultMemoryLayout = null;
            const layout: pjrt.MemoryLayout = switch (platform.target) {
                .tpu => blk: {
                    default_layout = try platform.pjrt_client.defaultMemoryLayout(
                        platform.pjrt_api,
                        pjrtx.bufferTypeFromDtype(shard.shape.dtype()),
                        shard.shape.dims(),
                    );
                    break :blk default_layout.?.toMemoryLayout();
                },
                else => .{
                    .tiled = .{
                        .minor_to_major = constants.minorToMajor(shard.shape.rank()),
                        .tile_dims = &.{},
                        .tile_dims_sizes = &.{},
                    },
                },
            };
            const args: pjrt.Client.CreateUninitializedBufferArgs = .{
                .dims = shard.shape.dims(),
                .element_type = pjrtx.bufferTypeFromDtype(shard.shape.dtype()),
                .layout = layout,
                .dst = .{ .memory = shard.memory(platform, opts.memory).pjrt_memory },
            };

            const shard_buffer = try platform.pjrt_client.createUninitializedBuffer(platform.pjrt_api, args);
            res._shards.appendAssumeCapacity(shard_buffer);
        }

        return res;
    }

    /// Wraps pre-exisiting `pjrt.Buffer` shards into one `zml.Buffer`.
    pub fn fromPjrtBuffers(platform: *const Platform, sh: Shape, sharding: Sharding, pjrt_buffers: []const *pjrt.Buffer) Buffer {
        stdx.debug.assert(pjrt_buffers.len <= MAX_NUM_SHARDS, "ZML doesn't support having more than {} shards. Received {} shards for one buffer.", .{ MAX_NUM_SHARDS, pjrt_buffers.len });
        stdx.debug.assert(pjrt_buffers.len > 0, "fromPjrtBuffers expects at least one buffer, got 0.", .{});

        return .{
            ._platform = platform,
            ._shape = sh,
            ._sharding = sharding,
            ._shards = Shards.fromSlice(pjrt_buffers) catch unreachable,
        };
    }

    /// Fetches the content of the given buffer into a stack variable of the given type.
    pub fn getValue(self: Buffer, T: type, io: std.Io) !T {
        stdx.debug.assert(self._shape.byteSize() == @sizeOf(T), "Buffer {f} has {d} bytes of data, can't load it to a {s} with {d} bytes", .{ self, self._shape.byteSize(), @typeName(T), @sizeOf(T) });
        var res: T = undefined;

        try self.toSlice(io, .init(self.shape(), std.mem.asBytes(&res)));

        return res;
    }

    /// Copies the content of the Buffer to the provided slice.
    pub fn toSlice(self: Buffer, io: std.Io, slice: Slice) !void {
        stdx.debug.assert(self._shape.eql(slice.shape), "Buffer shape {f} doesn't match destination slice {f}", .{ self._shape, slice.shape });

        for (self.placement().shards.constSlice(), 0..) |shard, shard_index| {
            const sub_slice = shard.shardSlice(slice);
            if (!sub_slice.isContiguous()) return error.NonContiguousShardRead;

            const size_bytes = shard.shape.byteSize();
            const start = sub_slice.offset_bytes;
            const end = start + size_bytes;
            stdx.debug.assert(end <= slice.constData().len, "Shard sub_slice exceeds destination slice", .{});

            const destination = slice.data()[start..end];
            const maybe_event = try self._shards.get(shard_index).toHostBuffer(self._platform.pjrt_api, destination);

            if (maybe_event) |event| {
                try event.await(self._platform.pjrt_api, io);
            }
        }
    }

    /// Copies the content of the Buffer to the provided slice.
    /// The returned slice owns the memory.
    pub fn toSliceAlloc(self: Buffer, allocator: std.mem.Allocator, io: std.Io) !Slice {
        const slice = try Slice.alloc(allocator, self.shape());
        errdefer slice.free(allocator);

        for (self.placement().shards.constSlice(), 0..) |shard, shard_index| {
            const sub_slice = shard.shardSlice(slice);

            var shard_slice = try Slice.alloc(allocator, sub_slice.shape);
            defer shard_slice.free(allocator);

            const maybe_event = try self._shards.get(shard_index).toHostBuffer(self._platform.pjrt_api, shard_slice.data());
            if (maybe_event) |event| {
                try event.await(self._platform.pjrt_api, io);
            }

            sub_slice.copy(shard_slice.constData());
        }

        return slice;
    }

    pub fn byteSize(self: Buffer) usize {
        var byte_size: usize = 0;

        for (self.placement().shards.constSlice()) |shard| {
            byte_size += shard.shape.byteSize();
        }

        return byte_size;
    }

    pub fn placement(self: Buffer) Placement {
        return Placement.init(self._sharding, self._shape) catch unreachable;
    }
};
